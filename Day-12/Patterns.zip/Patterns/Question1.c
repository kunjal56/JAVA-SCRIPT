#include<stdio.h>

// Q.1 Write a Program to print 1 to 10 using a do-while loop.

main(){
	
	int g = 1;
	
	do{
		printf("%d\n",g);
		g++;
	}
	while(g <= 10);
}
