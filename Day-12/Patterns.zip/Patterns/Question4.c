#include<stdio.h>

// Q.4 Write a Program to print 1 to 10 using a for loop.

main(){
	
	int a;
	
	for (a=1;a<=10;a++){
		printf("%d\n",a);
	}
}
